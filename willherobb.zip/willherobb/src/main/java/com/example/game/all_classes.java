package com.example.game;

import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Stack;
import java.util.concurrent.TimeUnit;


public class all_classes implements Serializable {
//    @FXML
//    Pane
    public static Orc global_orc;
    static class player implements Serializable{
        public String name = "";
        public  int coins_earned = 0;
        public  int player_position=0;
        public  int carrying_weapon=0;
        public int dead_once = 0;

        public void setName(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setDead_once(int dead_once) {
            this.dead_once += dead_once;
        }

        public int getDead_once(){
            return dead_once;
        }

        public  void setCarrying_weapon(int wp) {
            carrying_weapon = wp;
        }

        public  int getCarrying_weapon() {
            return carrying_weapon;
        }

        public void setPlayer_position(int i) {
            player_position += i;
        }

        public int getPlayer_position() {
            return player_position;
        }

        public int getCoins_earned() {
            return coins_earned;
        }

        public void setCoins_earned(int coins) {
            coins_earned += coins;
        }
    }

    static class islands{
        public static ArrayList<Rectangle> all_islands = new ArrayList<>();
        public void add_island(Rectangle r) {
            all_islands.add(r);
        }
    }

    static class coin_chests {

        public static ArrayList<Rectangle> all_coin_chests = new ArrayList<>();
        public static ArrayList<ImageView> coin_chests_images = new ArrayList<>();
        public static ArrayList<ImageView> open_coin_chests_images = new ArrayList<>();

        public int no_of_coins = 50;
//        public coin_chests(Rectangle r,ImageView i1,ImageView i2){
//            all_coin_chests.add(r);
//            coin_chests_images.add(i1);
//            open_coin_chests_images.add(i2);
//        }
        public void add_coin_chest(Rectangle r){
            all_coin_chests.add(r);
        }
        public void add_coin_chest_images(ImageView r){
            coin_chests_images.add(r);
        }
        public void add_open_coin_chest_images(ImageView r){
            open_coin_chests_images.add(r);
        }
        public void remove_coin_chest_images(ImageView r){
            coin_chests_images.remove(r);
        }
        public void remove_open_coin_chest_images(ImageView r){
            open_coin_chests_images.remove(r);
        }

    }

    static class weapon_chests{
//        public static Rectangle weapon_chest_rec;
        public  ImageView weapon_chest_image;
        public  ImageView open_weapon_chest_image;
        public int weapon_no;

        public weapon_chests( ImageView i1, ImageView i2, int w_no){
//            weapon_chest_rec = r;
            weapon_chest_image = i1;
            open_weapon_chest_image = i2;
            weapon_no = w_no;
        }


    }

    static class th extends Thread{
        @Override
        public void run(){
            try {
                Thread.sleep(700);
                System.out.println("sleeping thread");
                global_orc.sleeping = false;

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//            System.out.println("thread");
        }
    }

    static class Orc  {

        public  Rectangle orc_top;
        public  Rectangle orc_bottom;
        public  Rectangle orc_front;
        public  ImageView orc_image;
        public boolean sleeping = false;
        public boolean is_alive = true;
        public boolean can_jump = true;
        public boolean is_boss;
        public int health = 100;

        public static void setIs_alive(Orc orc,boolean is_alive) {
            orc.is_alive = is_alive;
        }

        public static boolean getIsAlive(Orc orc){
            return orc.is_alive;
        }

        public static boolean getsleep(Orc orc){
            return orc.sleeping;
        }

        public static int getHealth(Orc orc) {
            return orc.health;
        }
        //        public boolean can_be_detected = true;

//        public static ArrayList<ImageView> open_coin_chests_images = new ArrayList<>();

//        public int no_of_coins = 50;




        public Orc(Rectangle top,Rectangle bottom,Rectangle front,ImageView image,boolean boss){
            orc_top = top;
            orc_bottom = bottom;
            orc_front = front;
            orc_image = image;
            is_boss = boss;
        }
        public static void sleep(Orc orc) throws InterruptedException {
            th t1 = new th();
            global_orc = orc;
            orc.sleeping = true;
            t1.start();
//            System.out.println("sleep");
        }

        public static void jump(Orc orc) throws InterruptedException {
            if (orc.is_alive) {


                TranslateTransition t1 = new TranslateTransition(Duration.millis(750), orc.orc_front);
                TranslateTransition t2 = new TranslateTransition(Duration.millis(750), orc.orc_top);
                TranslateTransition t3 = new TranslateTransition(Duration.millis(750), orc.orc_bottom);
                TranslateTransition t4 = new TranslateTransition(Duration.millis(750), orc.orc_image);

                t1.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
                t2.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
                t3.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
                t4.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
                t1.setByY(t1.getByY() - 50);
                t2.setByY(t2.getByY() - 50);
                t3.setByY(t3.getByY() - 50);
                t4.setByY(t4.getByY() - 50);
//            t1.setAutoReverse(true);
//            t2.setAutoReverse(true);
//            t3.setAutoReverse(true);
//            t4.setAutoReverse(true);
//            t1.setCycleCount(200);
//            t2.setCycleCount(200);
//            t3.setCycleCount(200);
//            t4.setCycleCount(200);
//            TimeUnit.MILLISECONDS.sleep(200);

                t1.play();
                t2.play();
                t3.play();
                t4.play();
//            System.out.println("jump orc");
                t4.setOnFinished(actionEvent -> {
                    orc_freefall(orc, 1750);
                });
//            orc.getClass().getDeclaredFields();


//            coin_chests_images.add(r);
//            orc_freefall(orc);
            }
        }

        public static void orc_freefall(Orc orc,double time) {

            TranslateTransition t1 = new TranslateTransition(Duration.millis(time), orc.orc_front);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(time), orc.orc_top);
            TranslateTransition t3 = new TranslateTransition(Duration.millis(time), orc.orc_bottom);
            TranslateTransition t4 = new TranslateTransition(Duration.millis(time), orc.orc_image);

            t1.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t2.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t3.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t4.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t1.setToY(t1.getByY() + 150);
            t2.setToY(t2.getByY() + 150);
            t3.setToY(t3.getByY() + 150);
            t4.setToY(t4.getByY() + 150);
            t1.play();
            t2.play();
            t3.play();
            t4.play();
        }

        public static void boss_fall(Orc orc,double time) {

            TranslateTransition t1 = new TranslateTransition(Duration.millis(time), orc.orc_front);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(time), orc.orc_top);
            TranslateTransition t3 = new TranslateTransition(Duration.millis(time), orc.orc_bottom);
            TranslateTransition t4 = new TranslateTransition(Duration.millis(time), orc.orc_image);

            t1.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t2.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t3.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t4.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
            t1.setToY(t1.getByY() + 1150);
            t2.setToY(t2.getByY() + 1150);
            t3.setToY(t3.getByY() + 1150);
            t4.setToY(t4.getByY() + 1150);
            t1.play();
            t2.play();
            t3.play();
            t4.play();
        }


        public static void move(Orc orc,double dist){
            System.out.println("orc move");
            TranslateTransition t1 = new TranslateTransition(Duration.millis(250), orc.orc_front);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(250), orc.orc_top);
            TranslateTransition t3 = new TranslateTransition(Duration.millis(250), orc.orc_bottom);
            TranslateTransition t4 = new TranslateTransition(Duration.millis(250), orc.orc_image);

            t1.setByX(t1.getByX() + dist);
            t2.setByX(t2.getByX() + dist);
            t3.setByX(t3.getByX() + dist);
            t4.setByX(t4.getByX() + dist);

            t1.play();
            t2.play();
            t3.play();
            t4.play();

        }

        public static void kill_orc(Orc orc) throws InterruptedException {
            sleep(orc);
//            orc_freefall(orc,100);
            orc.is_alive = false;
        }

        public static void change_health(Orc orc,int health) throws InterruptedException {
            orc.health += health;
            if (orc.health<0){
                kill_orc(orc);
            }
        }

        public static void detect_collision(ArrayList<Orc> list_of_orcs, ImageView hero, ArrayList<Rectangle> islands, Pane new_pane, Label pos) throws InterruptedException {

            for (Orc orc : list_of_orcs) {
                if (orc.is_alive){


    //            1. orc bottom and islands

                    for (Rectangle island : islands) {
                        if (orc.orc_bottom.getBoundsInParent().intersects(island.getBoundsInParent())) {
                            jump(orc);
//                    System.out.println("orc land");
                        }
                    }
                    if (!orc.sleeping) {
                        HelloController hi = new HelloController();


                        //            2. orc front and hero

                        if (orc.orc_front.getBoundsInParent().intersects(hero.getBoundsInParent())) {
                            sleep(orc);
                            double dist = 40;
                            if (orc.is_boss) {
                                dist = 10;
                                sleep(orc);
                                change_health(orc,-20);
                                if (getHealth(orc)<0){
                                    kill_orc(orc);
                                    boss_fall(orc,500);
                                    orc.orc_image.setVisible(false);
                                    System.out.println("boss dead");
                                    orc.is_alive=false;

                                }
                                hi.move_hero_back(new_pane,pos);
                            }
                            move(orc, dist);
                        }

                        //            3. orc bottom on hero
                        if (orc.orc_bottom.getBoundsInParent().intersects(hero.getBoundsInParent())) {
                            sleep(orc);
                            HelloController.is_hero_dead =true;
//                            hi.setIs_hero_dead();

//                            System.out.println("----------GAME OVER -------------");
                        }

                        //            3. hero on orc top

                        if (orc.orc_top.getBoundsInParent().intersects(hero.getBoundsInParent())) {
                            System.out.println("top");
                            hi.jump_hero(hero);
                            orc_freefall(orc, 1750);
                            sleep(orc);


    //                         System.out.println("----------GAME OVER -------------");

                        }
                    }
                }
            }
        }
    }


}
