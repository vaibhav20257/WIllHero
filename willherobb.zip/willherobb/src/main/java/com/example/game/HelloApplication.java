package com.example.game;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Scanner sc =new Scanner(System.in);
//        int inp = sc.nextInt();
//        if (inp == 1){
//            try {
//                Parent root=FXMLLoader.load(getClass().getResource("newfile.fxml"));
//                Scene scene=new Scene(root);
//                stage.setResizable(false);
//                stage.setScene(scene);
//                stage.show();
//            }
//            catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        if (inp == 2){
            try {
                Parent root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game-play.fxml")));
                Scene scene=new Scene(root);
                stage.setResizable(false);

//                scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
//                    @Override
//                    public void handle(MouseEvent mouseEvent) {
//                        sceneController scc = new sceneController();
//                        scc.move_hero();
//                        MainMenu mt = new MainMenu();
//                        mt.
//                        System.out.println("moving");
//
//
//
//                    }
//                });

                stage.setScene(scene);
                stage.show();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
//    }

    public static void main(String[] args) {
        launch();
    }
}