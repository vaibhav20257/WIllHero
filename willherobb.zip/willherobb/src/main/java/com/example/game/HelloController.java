package com.example.game;

import javafx.animation.AnimationTimer;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;

import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;


import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;


public class HelloController implements Initializable {

    public FlowPane first_flow;
//    public AnchorPane mov;
//    public Pane new_p;

    public Pane new_flow;
    public Pane new_pane;
    public Rectangle land2;
    public Rectangle land1;
    public Pane move_pane;
    public Rectangle land3;
    public Label total_coin_label;
    public Rectangle coin_chest_1;
    public ImageView coins_icon;
    public ImageView open_coin_chest_img_1;
    public ImageView coin_chest_img_1;
    public ImageView island4;
    public ImageView open_coin_chest_img_2;
    public ImageView coin_chest_img_2;
    public Rectangle land4;
    public Rectangle coin_chest_2;
    public Label player_pos;
    public Rectangle orc_1_bottom;
    public Rectangle orc_1_top;
    public Rectangle orc_1_front;
    public ImageView orc_1;
    public ImageView orc_2;
    public Rectangle orc_2_top;
    public Rectangle orc_2_front;
    public Rectangle orc_2_bottom;
    public ImageView weapon_4;
    public ImageView weapon_3;
    public ImageView weapon_2;
    public ImageView weapon_1;
    public ImageView open_weapon_chest_1;
    public ImageView weapon_chest_1;
    public ImageView knife_a;
    public ImageView knife_b;
    public ImageView knife_c;
    public Rectangle land5;
    public Rectangle land6;
    public Rectangle land7;
    public Rectangle land8;
    public Rectangle land9;
    public Rectangle land10;
    public Rectangle land11;
    public Rectangle land12;
    public Rectangle land13;
    public Rectangle land14;
    public Rectangle land15;
    public Rectangle land16;
    public Rectangle land17;
    public Rectangle land18;
    public Rectangle land01;
    public Rectangle land02;
    public Rectangle land03;
    public Rectangle land04;
    public ImageView open_coin_chest_img_3;
    public Rectangle coin_chest_3;
    public ImageView coin_chest_img_3;
    public ImageView open_coin_chest_img_4;
    public Rectangle coin_chest_4;
    public ImageView coin_chest_img_4;
    public ImageView open_coin_chest_img_5;
    public Rectangle coin_chest_5;
    public ImageView coin_chest_img_5;
    public ImageView open_coin_chest_img_6;
    public Rectangle coin_chest_6;
    public ImageView coin_chest_img_6;
    public ImageView open_coin_chest_img_7;
    public Rectangle coin_chest_7;
    public ImageView coin_chest_img_7;
    public ImageView open_coin_chest_img_8;
    public Rectangle coin_chest_8;
    public ImageView coin_chest_img_8;
    public ImageView open_weapon_chest_2;
    public ImageView open_weapon_chest_3;
    public ImageView open_weapon_chest_4;
    public ImageView weapon_chest_2;
    public ImageView weapon_chest_3;
    public ImageView weapon_chest_4;
    public ImageView boss;
    public Rectangle orc_3_top;
    public Rectangle orc_3_front;
    public Rectangle orc_3_bottom;
    public Rectangle orc_4_top;
    public Rectangle orc_4_front;
    public Rectangle orc_4_bottom;
    public Rectangle orc_5_top;
    public Rectangle orc_5_front;
    public Rectangle orc_5_bottom;
    public ImageView orc_3;
    public ImageView orc_4;
    public ImageView orc_5;
    public ImageView orc_6;
    public ImageView island_01;
    public ImageView island_02;
    public ImageView island_03;
    public ImageView island_04;
    public Rectangle orc_6_top;
    public Rectangle orc_6_front;
    public Rectangle orc_6_bottom;
    public Pane pause_pane;
    public Button pause_button;
    public Button res_button;
    public Button cross_button;
    public Label game_over_label;
    public Button save_game_button;
    public TextField new_game_text;
    public TextField load_game_text;
    public Button load_game_button;
    public Label load_game_label;
    public Label save_game_label;
    public Label new_game_label;
    public ImageView plank1;
    public ImageView plank2;
    public Button new_game_button;
    public Label menu_label;
    public ImageView pause_bg;
    public ImageView setting_button;
    public ImageView pause_bgg;
    public ImageView winner;


    //    public ImageView island4;
    //    public ImageView
    @FXML
    private ImageView hero;
    @FXML
    private ImageView island1;
//    @FXML
//    private ImageView coin_chest_img_1;



//    class weapon_chest implements chest{
//        ArrayList<Rectangle> weapon_chest_list = new ArrayList<>();
//        @Override
//        public void add_chest(Rectangle r) {
//            weapon_chest_list.add(r);
//        }
//    }
//
//    class coin_chest implements chest{
//        ArrayList<Rectangle> coin_chest_list = new ArrayList<>();
//        @Override
//        public void add_chest(Rectangle r) {
//            coin_chest_list.add(r);
//        }
//    }



    ArrayList<ImageView> weapon_icons = new ArrayList<>();
    ArrayList<all_classes.Orc> orc_list = new ArrayList<>();
    ArrayList<all_classes.weapon_chests> weapon_chest_list = new ArrayList<>();
    static boolean is_hero_dead = false;
    static boolean file_written = false;
    boolean is_peek_reversed = true;

    ArrayList<ImageView> current_weapons = new ArrayList<>();
    all_classes.player player1 = new all_classes.player();

    AnimationTimer check_hero_dead_timer = new AnimationTimer() {
        private long last_update = 0;
        @Override
        public void handle(long now) {
            if (now-last_update>= 10_000_000){
                try {
                    check_hero_dead(hero);
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
                last_update = now;
            }

        }
    };

    AnimationTimer check_orc_dead_timer = new AnimationTimer() {
        private long last_update = 0;
        @Override
        public void handle(long now) {
            if (now-last_update>= 100_000_000){
                try {
                    check_orc_dead(orc_list);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
//                check_hero_dead(hero);
                last_update = now;
            }

        }
    };

    AnimationTimer hero_package_move_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
        }
    };

    AnimationTimer fall_platform_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
//            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
            fall_platform(hero,land01,land02,land03,land04);

        }
    };

    AnimationTimer weapon_orc_collision_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
//            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
            try {
                weapon_orc_collision(orc_list,current_weapons);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };

    AnimationTimer weapon_2_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
        }
    };

    AnimationTimer weapon_3_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
        }
    };

    AnimationTimer weapon_4_timer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            hero_package_move(hero,weapon_1,weapon_2,weapon_3,weapon_4);
        }
    };

    AnimationTimer orc_collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            try {
                all_classes.Orc.detect_collision(orc_list,hero, all_classes.islands.all_islands,move_pane,player_pos);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };


    AnimationTimer collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            checkCollision(hero, all_classes.islands.all_islands);
        }
    };

    AnimationTimer weapon_chest_collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            check_weapon_chest_collision(hero,weapon_chest_list,weapon_icons);
        }
    };

    AnimationTimer coin_chest_collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long l) {
            check_coin_chest_Collision(hero, all_classes.coin_chests.all_coin_chests);
        }
    };
//    Freefall freefall = new Freefall();

//    TranslateTransition t11 = new TranslateTransition(Duration.millis(550), hero);

//    AnimationTimer jumpTimer = new AnimationTimer() {
//        @Override
//        public void handle(long l) {
//            t11.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
//            t11.setFromY(t11.getByY()+200);
////            t11.s
////            t1.setAutoReverse(true);
//            t11.setCycleCount(Integer.MAX_VALUE);
//            t11.play();
//            System.out.println("jumping");
//        }
//    };

    @Override


    public void initialize(URL url, ResourceBundle resourceBundle) {
        all_classes.islands land = new all_classes.islands();
        all_classes.coin_chests chests_ob = new all_classes.coin_chests();
//        all_classes.player player1 = new all_classes.player();

        all_classes.Orc orc1 = new all_classes.Orc(orc_1_top,orc_1_bottom,orc_1_front,orc_1,false);
        all_classes.Orc orc2 = new all_classes.Orc(orc_2_top,orc_2_bottom,orc_2_front,orc_2,false);
        all_classes.Orc orc3 = new all_classes.Orc(orc_3_top,orc_3_bottom,orc_3_front,orc_3,false);
        all_classes.Orc orc4 = new all_classes.Orc(orc_4_top,orc_4_bottom,orc_4_front,orc_4,false);
        all_classes.Orc orc5 = new all_classes.Orc(orc_5_top,orc_5_bottom,orc_5_front,orc_5,false);
        all_classes.Orc orc6 = new all_classes.Orc(orc_6_top,orc_6_bottom,orc_6_front,orc_6,true);

        orc_list.add(orc1);
        orc_list.add(orc2);
        orc_list.add(orc3);
        orc_list.add(orc4);
        orc_list.add(orc5);
        orc_list.add(orc6);


        all_classes.weapon_chests weapon_1_chest = new all_classes.weapon_chests(weapon_chest_1,open_weapon_chest_1,1);
        all_classes.weapon_chests weapon_2_chest = new all_classes.weapon_chests(weapon_chest_2,open_weapon_chest_2,2);
        all_classes.weapon_chests weapon_3_chest = new all_classes.weapon_chests(weapon_chest_3,open_weapon_chest_3,3);
        all_classes.weapon_chests weapon_4_chest = new all_classes.weapon_chests(weapon_chest_4,open_weapon_chest_4,4);

        weapon_chest_list.add(weapon_1_chest);
        weapon_chest_list.add(weapon_2_chest);
        weapon_chest_list.add(weapon_3_chest);
        weapon_chest_list.add(weapon_4_chest);

//      initiating orcs
        for ( all_classes.Orc each_orc:orc_list){
            all_classes.Orc.orc_freefall(each_orc,1750);

        }
//        temp=orc;

        weapon_icons.add(weapon_1);
        weapon_icons.add(weapon_2);
        weapon_icons.add(weapon_3);
        weapon_icons.add(weapon_4);

//        islands
        {
            land.add_island(land1);
            land.add_island(land2);
            land.add_island(land3);
            land.add_island(land4);
            land.add_island(land5);
            land.add_island(land6);
            land.add_island(land7);
            land.add_island(land8);
            land.add_island(land9);
            land.add_island(land10);
            land.add_island(land11);
            land.add_island(land12);
            land.add_island(land13);
            land.add_island(land14);
            land.add_island(land15);
            land.add_island(land16);
            land.add_island(land17);
            land.add_island(land18);
            land.add_island(land01);
            land.add_island(land02);
            land.add_island(land03);
            land.add_island(land04);
        }
//       coin chests
        {
            chests_ob.add_coin_chest(coin_chest_1);
            chests_ob.add_coin_chest_images(coin_chest_img_1);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_1);

            chests_ob.add_coin_chest(coin_chest_2);
            chests_ob.add_coin_chest_images(coin_chest_img_2);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_2);

            chests_ob.add_coin_chest(coin_chest_3);
            chests_ob.add_coin_chest_images(coin_chest_img_3);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_3);

            chests_ob.add_coin_chest(coin_chest_4);
            chests_ob.add_coin_chest_images(coin_chest_img_4);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_4);

            chests_ob.add_coin_chest(coin_chest_5);
            chests_ob.add_coin_chest_images(coin_chest_img_5);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_5);

            chests_ob.add_coin_chest(coin_chest_6);
            chests_ob.add_coin_chest_images(coin_chest_img_6);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_6);

            chests_ob.add_coin_chest(coin_chest_7);
            chests_ob.add_coin_chest_images(coin_chest_img_7);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_7);

            chests_ob.add_coin_chest(coin_chest_8);
            chests_ob.add_coin_chest_images(coin_chest_img_8);
            chests_ob.add_open_coin_chest_images(open_coin_chest_img_8);
        }




        freefall();
        collisionTimer.start();
        coin_chest_collisionTimer.start();
        orc_collisionTimer.start();
        hero_package_move_timer.start();
        weapon_chest_collisionTimer.start();
        check_hero_dead_timer.start();
        check_orc_dead_timer.start();
        new_pane=move_pane;
        fall_platform_timer.start();





    }

    public void cross_button(){
        pause_pane.setVisible(false);
    }

    public void setting_button(){
        pause_pane.setVisible(true);
    }



    public void fire_weapon_1(){
        TranslateTransition t0 = new TranslateTransition(Duration.millis(50),knife_a);
        double hero_y0 = hero.getBoundsInParent().getMinY();
        knife_a.setLayoutY(hero_y0+14);
        t0.play();
//        player1
        t0.setOnFinished(actionEvent -> {knife_a.setVisible(true);});

        TranslateTransition t1 = new TranslateTransition(Duration.millis(200),knife_a);
        double hero_x = hero.getBoundsInParent().getMinX();
        t1.setByX(t1.getByX()+200);
        t1.play();

        t1.setOnFinished(actionEvent -> {
            knife_a.setVisible(false);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(50),knife_a);
            t2.setToX(hero_x-60);
            t2.play();
        });
    }

    public void fire_weapon_2(){
        TranslateTransition t01 = new TranslateTransition(Duration.millis(20),knife_a);
        double hero_y0 = hero.getBoundsInParent().getMinY();
        knife_a.setLayoutY(hero_y0+14);
        knife_b.setLayoutY(hero_y0+29);
        knife_c.setLayoutY(hero_y0-1);
        t01.play();

        t01.setOnFinished(actionEvent -> {
            knife_a.setVisible(true);
            knife_b.setVisible(true);
            knife_c.setVisible(true);
        });

        TranslateTransition t1 = new TranslateTransition(Duration.millis(200),knife_a);
        TranslateTransition t2 = new TranslateTransition(Duration.millis(200),knife_b);
        TranslateTransition t3 = new TranslateTransition(Duration.millis(200),knife_c);

        double hero_x = hero.getBoundsInParent().getMinX();
        t1.setByX(t1.getByX()+200);
        t2.setByX(t3.getByX()+200);
        t3.setByX(t3.getByX()+200);
        t1.play();
        t2.play();
        t3.play();

        t1.setOnFinished(actionEvent -> {
            knife_a.setVisible(false);
            knife_b.setVisible(false);
            knife_c.setVisible(false);
            TranslateTransition t4 = new TranslateTransition(Duration.millis(5),knife_a);
            TranslateTransition t5 = new TranslateTransition(Duration.millis(5),knife_b);
            TranslateTransition t6 = new TranslateTransition(Duration.millis(5),knife_c);
            t4.setToX(hero_x-60);
            t5.setToX(hero_x-60);
            t6.setToX(hero_x-60);
            t4.play();
            t5.play();
            t6.play();
        });
    }


    public void move_hero_back(Pane new_pane2,Label pos){
        for(Node nd:new_pane2.getChildren()){
            TranslateTransition t5 = new TranslateTransition(Duration.millis(300),nd);
            t5.setToX(nd.getTranslateX()+80);
            t5.play();
        }
        player1.setPlayer_position(-1);
        pos.setText(Integer.toString(player1.getPlayer_position()));
    }

    public void move_hero(MouseEvent mouseEvent) {
        hero_peek();
//        fire_weapon_2();

        if (player1.getCarrying_weapon()==1){
            fire_weapon_1();
        }
        if (player1.getCarrying_weapon()==2){
            fire_weapon_2();
        }
            TranslateTransition t3 = new TranslateTransition(Duration.millis(100),hero);
        player1.setPlayer_position(1);
        player_pos.setText(Integer.toString(player1.getPlayer_position()));
//            t3.setToX(hero.getTranslateX()+100);
//            System.out.println("moving");
//            t3.play();
//        movable_pane.
//            TranslateTransition t4 = new TranslateTransition(Duration.millis(200),movable_pane);
//            t4.setToX(movable_pane.getTranslateX()-100);
//            t4.play();
//            move_pane.setLayoutX(move_pane.getLayoutX()-100);
//            for (move_pane.getChildren()){
//                System.out.println();
//            }
        for(Node nd:move_pane.getChildren()){
            TranslateTransition t5 = new TranslateTransition(Duration.millis(300),nd);
            t5.setToX(nd.getTranslateX()-100);
//            t5.setDelay(Duration.millis(1000));
            t5.play();
        }
//        System.out.println("pane move");
    }


    public void hero_peek(){
        if (is_peek_reversed) {
            TranslateTransition t1 = new TranslateTransition(Duration.millis(150), hero);

//        t1.setAutoReverse(true);
            t1.setByX(t1.getByX() + 30);
//        t1.setCycleCount(2);
            t1.play();
            is_peek_reversed=false;
            t1.setOnFinished(actionEvent -> {
                hero_peek_reverse();
            });
        }
    }
    public void hero_peek_reverse(){
        TranslateTransition t1 = new TranslateTransition(Duration.millis(150), hero);
//        t1.setAutoReverse(true);
        t1.setByX(t1.getByX()-30);
//        t1.setCycleCount(2);
        t1.play();
        t1.setOnFinished(actionEvent -> {
            is_peek_reversed = true;
        });
    }



    void freefall() {
        TranslateTransition t11 = new TranslateTransition(Duration.millis(2000), hero);
        t11.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
        t11.setByY(t11.getByY() + 600);
        t11.play();
//        System.out.println("free fall");

    }

    public void hero_package_move(ImageView hero1,ImageView knife_logo,ImageView knife_pro,ImageView sword,ImageView long_sword){
        double hero_x = hero1.getBoundsInParent().getMinX();
        double hero_y = hero1.getBoundsInParent().getMinY();
//        System.out.println(hero1.getBoundsInParent().getMinY());
        knife_logo.setLayoutX(hero_x-6);
        knife_logo.setLayoutY(hero_y+4);
        knife_pro.setLayoutX(hero_x-15);
        knife_pro.setLayoutY(hero_y-11);
        sword.setLayoutX(hero_x+56);
        sword.setLayoutY(hero_y-6);
        long_sword.setLayoutX(hero_x+52);
        long_sword.setLayoutY(hero_y-15);
    }

    public void start_load_game() throws IOException, ClassNotFoundException {
        String s1 = load_game_text.getText();
        s1 = "C:\\Users\\SEJWAL\\Desktop\\Game\\"+s1+".ser";
        all_classes.player p1 = null;
        FileInputStream filein = new FileInputStream(s1);
        ObjectInputStream in = new ObjectInputStream(filein);
        p1 = (all_classes.player) in.readObject();
        player1 = p1;
        in.close();
        filein.close();
        System.out.println("loaded");
        player_pos.setText(Integer.toString(player1.getPlayer_position()));
        total_coin_label.setText(Integer.toString(player1.getCoins_earned()));




        for(Node nd:move_pane.getChildren()){
            TranslateTransition t5 = new TranslateTransition(Duration.millis(30),nd);
            t5.setToX(nd.getTranslateX()+(player1.getPlayer_position()*(-100)));
//            t5.setDelay(Duration.millis(1000));
            t5.play();
        }
        pause_pane.setVisible(false);

//        player1.setPlayer_position();


        System.out.println(player1.carrying_weapon);
        System.out.println(player1.coins_earned);
        System.out.println(player1.player_position);
    }


    public void save_game() throws IOException {
        FileOutputStream fileout = new FileOutputStream(player1.getName());
        ObjectOutputStream out = new ObjectOutputStream(fileout);
        out.writeObject(player1);
        out.close();
        fileout.close();
        pause_pane.setVisible(false);
        System.out.println("save game");
    }

    public void start_new_game() throws IOException {
        String s1 = new_game_text.getText();
        s1 = s1+".ser";
        player1.setName(s1);
        FileOutputStream fileout = new FileOutputStream(s1);
        ObjectOutputStream out = new ObjectOutputStream(fileout);
        out.writeObject(player1);
        out.close();
        fileout.close();
        pause_pane.setVisible(false);
        System.out.println("new game");
    }

    public void pause() throws IOException, ClassNotFoundException {
//        FileOutputStream fileout = new FileOutputStream("UserInfo.ser");
//        ObjectOutputStream out = new ObjectOutputStream(fileout);
//        out.writeObject(player1);
//        out.close();
//        fileout.close();
        pause_pane.setVisible(true);



//        all_classes.player p1 = null;
//        FileInputStream filein = new FileInputStream("C:\\Users\\SEJWAL\\Desktop\\Game\\UserInfo.ser");
//        ObjectInputStream in = new ObjectInputStream(filein);
//        p1 = (all_classes.player) in.readObject();
//        in.close();
//        filein.close();


        System.out.println(player1.carrying_weapon);
        System.out.println(player1.coins_earned);
        System.out.println(player1.player_position);
    }

    public void res(){
        if (player1.getDead_once()==1){
            if (player1.coins_earned >= 50){
                for(Node nd:move_pane.getChildren()) {
                    TranslateTransition t5 = new TranslateTransition(Duration.millis(100), nd);
                    t5.setToX(nd.getTranslateX() + 200);
                    t5.play();
                }

                pause_pane.setVisible(false);
                player1.setCoins_earned(-50);
                player1.setPlayer_position(-2);
                total_coin_label.setText(Integer.toString(player1.getCoins_earned()));
                hero.setY(0);
                jump_hero(hero);
                freefall();
            }
        }
        else
            System.out.println("cant res");
    }


    public void check_hero_dead(ImageView hero) throws IOException, ClassNotFoundException {
        double hero_y = hero.getBoundsInParent().getMinY();
        if (hero_y>300){
            is_hero_dead=true;
//            System.out.println("hero dead");
        }
//        System.out.println(is_hero_dead+"  ===== status");
        if (is_hero_dead) {
            if (player1.getDead_once()==0)
                player1.setDead_once(1);
            if (!file_written) {
                file_written = true;
                pause();
            }
//            System.out.println("hero dead");
        }

    }
    int flag = 0;
    public void check_orc_dead(ArrayList<all_classes.Orc> orcs_list) throws InterruptedException {
        for (all_classes.Orc each_orc:orcs_list) {
            if (!each_orc.is_alive){
                if (each_orc.is_boss){
                    if (flag==0) {
                        winner.setVisible(true);
//                        TranslateTransition tt = new TranslateTransition(Duration.millis(2000), coin_chest_1);
//                        tt.play();
//                        tt.setOnFinished(actionEvent -> {
//                            winner.setVisible(false);
//                            flag = 1;
//                            pause_pane.setVisible(true);
//                        });
                    }
                }
            }
            if (each_orc.is_alive) {
                if (each_orc.orc_image.getBoundsInParent().getMinY() > 270) {
                    all_classes.Orc.kill_orc(each_orc);
                    each_orc.orc_image.setVisible(false);
                    player1.setCoins_earned(100); //orc kill reward
                    coin_icon_scale_transition();
                    total_coin_label.setText(Integer.toString(player1.getCoins_earned()));
                }
            }
            if (each_orc.orc_image.getBoundsInParent().getMinY() > 270) {
                each_orc.orc_image.setVisible(false);
            }
        }

    }

    public void jump_hero(ImageView hero1){
        orc_collisionTimer.stop();
//        hero1.setY(200);
        TranslateTransition t12 = new TranslateTransition(Duration.millis(250), hero1);
        t12.setByY(t12.getByY()-0.1);
        t12.play();
        t12.setOnFinished(actionEvent -> {
            TranslateTransition t1 = new TranslateTransition(Duration.millis(550), hero1);
            t1.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
            t1.setByY(t1.getByY() - 100);
//                t1.setDelay(Duration.millis(1100));
            t1.play();
            t1.setOnFinished(event -> {
//                System.out.println("free2");
//                hero1.f
                TranslateTransition t11 = new TranslateTransition(Duration.millis(750), hero1);
                t11.interpolatorProperty().set(Interpolator.SPLINE(.6, .3, .2, .1));
                t11.setByY(t11.getByY() + 200);
                t11.play();
//                        System.out.println("again-----");
//                collisionTimer.start();
                orc_collisionTimer.start();
            });
        });
//        System.out.println("hero jumping");
    }
//
    public void weapon_orc_collision(ArrayList<all_classes.Orc> orc_list1,ArrayList<ImageView> curr_weapons) throws InterruptedException {
        for (all_classes.Orc each_orc: orc_list1){
//            System.out.println(each_orc.orc_image.getId());
            for (ImageView each_weapon:curr_weapons) {
//                System.out.println(each_weapon.getId());
                if (each_orc.orc_front.getBoundsInParent().intersects(each_weapon.getBoundsInParent())) {
                    if (!each_orc.is_boss) {
                        each_orc.orc_front.setLayoutX(0);
                        all_classes.Orc.kill_orc(each_orc);
                        all_classes.Orc.change_health(each_orc,-100);
                        System.out.println("orc kill");
                        player1.setCoins_earned(100); //orc kill reward
                        coin_icon_scale_transition();
                        total_coin_label.setText(Integer.toString(player1.getCoins_earned()));
                    }
                    else {
//                        boss orc collision

                        if (all_classes.Orc.getIsAlive(each_orc)) {
                            if (!all_classes.Orc.getsleep(each_orc)) {

                                all_classes.Orc.sleep(each_orc);
                                all_classes.Orc.change_health(each_orc, -34);
                                if (all_classes.Orc.getHealth(each_orc) < 0) {
                                    all_classes.Orc.setIs_alive(each_orc, false);
                                    all_classes.Orc.kill_orc(each_orc);
                                    all_classes.Orc.boss_fall(each_orc, 500);
                                    each_orc.orc_image.setVisible(false);
                                    player1.setCoins_earned(1000); //orc kill reward
                                    coin_icon_scale_transition();

                                    total_coin_label.setText(Integer.toString(player1.getCoins_earned()));
                                } else {
                                    move_hero_back(move_pane,player_pos);
                                    all_classes.Orc.move(each_orc, 10);
                                }
                            }
                        }


                    }
                }
            }
        }
    }

    public void check_weapon_chest_collision(ImageView hero, ArrayList<all_classes.weapon_chests> weapon_chest_list, ArrayList<ImageView> wp_icons){
        for (all_classes.weapon_chests wp:weapon_chest_list){
            if (hero.getBoundsInParent().intersects(wp.weapon_chest_image.getBoundsInParent())){
                wp.weapon_chest_image.setVisible(false);
                wp.weapon_chest_image.setLayoutX(0);
                wp.open_weapon_chest_image.setVisible(true);
//                System.out.println("weapon coll");
//                String sid =  wp.weapon_chest_image.getId().substring(13,14);
                int wno = wp.weapon_no;
                if (wno == 1){
                    if (player1.getCarrying_weapon()==1)
                        wno = 2;
                }
                if (wno == 3){
                    if (player1.getCarrying_weapon()==3)
                        wno = 4;
                }
                String sid = Integer.toString(wno);
                String s1 = "weapon_" + sid;
                player1.setCarrying_weapon(wp.weapon_no);
                if (wno==1){
                    current_weapons.clear();
                    current_weapons.add(knife_a);
                }
                if (wno==2){
                    current_weapons.clear();
                    current_weapons.add(knife_a);
                    current_weapons.add(knife_b);
                    current_weapons.add(knife_c);
                }
                if (wno==3){
                    current_weapons.clear();
                    current_weapons.add(weapon_3);
                }
                if (wno==4){
                    current_weapons.clear();
                    current_weapons.add(weapon_4);
                }

                for (ImageView wp_icon:wp_icons){
//                    System.out.println(s1);
//                    System.out.println(wp_icon.getId());
                    wp_icon.setVisible(Objects.equals(wp_icon.getId(), s1));

                }
                weapon_orc_collision_timer.start();

            }
        }
//        System.out.println(s1);
    }

    public void check_coin_chest_Collision(ImageView hero, ArrayList<Rectangle> coin_chests){
        for (Rectangle coin_chest:coin_chests){
            if (hero.getBoundsInParent().intersects(coin_chest.getBoundsInParent())){
                coin_chest.setLayoutX(0);
                all_classes.coin_chests chests_ob = new all_classes.coin_chests();

//                CHEST OPENING TRANSITION

                String sid =  coin_chest.getId().substring(11,12);
                String s1 = "coin_chest_img_"+sid;
                String s2 = "open_coin_chest_img_"+ sid;
                boolean flag1=false;
                boolean flag2=false;
                ImageView temp1 = null;
                ImageView temp2 = null;


                for (ImageView closed:all_classes.coin_chests.coin_chests_images){
                    if (Objects.equals(closed.getId(), s1)){
                        closed.setVisible(false);
                        flag1=true;
                        temp1=closed;
                    }
                }
                for (ImageView open:all_classes.coin_chests.open_coin_chests_images){
                    if (Objects.equals(open.getId(), s2)){
                        open.setVisible(true);
                        flag2=true;
                        temp2=open;
                    }
                }
                if (flag1)
                    chests_ob.remove_coin_chest_images(temp1);
                if (flag2)
                    chests_ob.remove_open_coin_chest_images(temp2);


//                COINS ADDED TO PLAYER CLASS AND SHOWN ON SCREEN

                player1.setCoins_earned(chests_ob.no_of_coins);
                total_coin_label.setText(Integer.toString(player1.getCoins_earned()));

//                COIN ICON SCALE TRANSITION
                coin_icon_scale_transition();

            }
        }
    }

    public void coin_icon_scale_transition(){

        TranslateTransition t1 = new TranslateTransition(Duration.millis(250), coins_icon);
        t1.getNode().setScaleX(1.7);
        t1.getNode().setScaleY(1.7);
        t1.play();
        t1.setOnFinished(actionEvent -> {
            TranslateTransition t2 = new TranslateTransition(Duration.millis(120), coins_icon);
            t2.setDelay(Duration.millis(200));
            t2.getNode().setScaleX(1);
            t2.getNode().setScaleY(1);
            t2.play();
        });
    }

//      CHECK ISLAND COLLISIONS AND JUMP ACCORDINGLY

    public void fall_platform(ImageView hero,Rectangle l1,Rectangle l2, Rectangle l3, Rectangle l4){
        if (hero.getBoundsInParent().intersects(l1.getBoundsInParent())){
            TranslateTransition t1 = new TranslateTransition(Duration.millis(6550), l1);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(6550), island_01);
            t1.setByY(t1.getByY()+400);
            t2.setByY(t2.getByY()+400);
            t1.play();
            t2.play();
        }
        if (hero.getBoundsInParent().intersects(l2.getBoundsInParent())){
            TranslateTransition t1 = new TranslateTransition(Duration.millis(6550), l2);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(6550), island_02);
            t1.setByY(t1.getByY()+400);
            t2.setByY(t2.getByY()+400);
            t1.play();
            t2.play();
        }if (hero.getBoundsInParent().intersects(l3.getBoundsInParent())){
            TranslateTransition t1 = new TranslateTransition(Duration.millis(6550), l3);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(6550), island_03);
            t1.setByY(t1.getByY()+400);
            t2.setByY(t2.getByY()+400);
            t1.play();
            t2.play();
        }if (hero.getBoundsInParent().intersects(l4.getBoundsInParent())){
            TranslateTransition t1 = new TranslateTransition(Duration.millis(6550), l4);
            TranslateTransition t2 = new TranslateTransition(Duration.millis(6550), island_04);
            t1.setByY(t1.getByY()+400);
            t2.setByY(t2.getByY()+400);
            t1.play();
            t2.play();
        }
    }

    public void checkCollision(ImageView hero,ArrayList<Rectangle> islands){
        for (Rectangle island:islands){
            if (hero.getBoundsInParent().intersects(island.getBoundsInParent())){
                collisionTimer.stop();
//                t11.stop();
//                freefall();
//                freefall.stop();
                TranslateTransition t12 = new TranslateTransition(Duration.millis(250), hero);
                t12.setByY(t12.getByY()-0.1);
                t12.play();
                t12.setOnFinished(actionEvent -> {
                    TranslateTransition t1 = new TranslateTransition(Duration.millis(550), hero);
                    t1.interpolatorProperty().set(Interpolator.SPLINE(.1, .3, .5, .85));
                    t1.setByY(t1.getByY()-100);
//                t1.setDelay(Duration.millis(1100));
                    t1.play();
                    t1.setOnFinished(event -> {
                        freefall();
//                        System.out.println("again-----");
                        collisionTimer.start();
                    });
                });



            }
        }
    }

}