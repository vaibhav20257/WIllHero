package com.example.game;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class sceneController {
    @FXML
    ImageView hero;
//    @FXML
//    public Pane
    public void move_hero(){
        TranslateTransition t1 = new TranslateTransition(Duration.millis(50),hero);
        t1.setToX(100);
        System.out.println("hksyfhla");
        t1.play();
    }
}
