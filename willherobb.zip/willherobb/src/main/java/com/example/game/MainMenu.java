package com.example.game;


import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.util.Duration;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class MainMenu implements Initializable {
    private Stage stage;
    private Scene scene;
    private ImageView hero;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){

    }
    public void GamePlay(ActionEvent actionEvent) throws IOException {
        Parent root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game-play.fxml")));
        stage=(Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void move() throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("game-play.fxml"));
        TranslateTransition t1 = new TranslateTransition(Duration.millis(50), hero);
        t1.setToX(100);
        t1.play();

    }
    public void Exit(ActionEvent actionEvent) throws IOException{
        System.exit(0);
    }
}